CREATE PROCEDURE AjouterStockVoiture
 @idVoiture int OUTPUT,
 @idMarque int,
 @idModele int,
 @idCategorie int,
 @anneeFabrication int,
 @idCarburant int,
 @idCouleur int,
 @kilometrage int
AS
 INSERT INTO StockVoiture(idMarque,idModele,idCategorie,anneeFabrication,idCarburant,idCouleur,kilometrage)
  VALUES(@idMarque,@idModele,@idCategorie,@anneeFabrication,@idCarburant,@idCouleur,@kilometrage)
 SET @idVoiture=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierStockVoiture
 @idVoiture int,
 @idMarque int,
 @idModele int,
 @idCategorie int,
 @anneeFabrication int,
 @idCarburant int,
 @idCouleur int,
 @kilometrage int
AS
 IF(@idVoiture IS NULL OR @idVoiture=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE StockVoiture
        SET idMarque=@idMarque,idModele=@idModele,idCategorie=@idCategorie,anneeFabrication=@anneeFabrication,idCarburant=@idCarburant,idCouleur=@idCouleur,kilometrage=@kilometrage
        WHERE idVoiture=@idVoiture
RETURN
GO
CREATE PROCEDURE SelectionnerStockVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='idMarque') SELECT * FROM StockVoiture ORDER BY idMarque
 ELSE IF(@Index='idModele') SELECT * FROM StockVoiture ORDER BY idModele
 ELSE IF(@Index='idCategorie') SELECT * FROM StockVoiture ORDER BY idCategorie
 ELSE IF(@Index='anneeFabrication') SELECT * FROM StockVoiture ORDER BY anneeFabrication
 ELSE IF(@Index='idCarburant') SELECT * FROM StockVoiture ORDER BY idCarburant
 ELSE IF(@Index='idCouleur') SELECT * FROM StockVoiture ORDER BY idCouleur
 ELSE IF(@Index='kilometrage') SELECT * FROM StockVoiture ORDER BY kilometrage
 ELSE SELECT * FROM StockVoiture ORDER BY idVoiture
RETURN
GO
CREATE PROCEDURE SelectionnerStockVoiture_ID
 @idVoiture int
AS
 IF(@idVoiture IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idVoiture,idMarque,idModele,idCategorie,anneeFabrication,idCarburant,idCouleur,kilometrage
  FROM StockVoiture
  WHERE @idVoiture=idVoiture
RETURN
GO
CREATE PROCEDURE SupprimerStockVoiture
 @idVoiture int
AS
 IF(@idVoiture IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM StockVoiture WHERE @idVoiture=idVoiture
RETURN
GO
