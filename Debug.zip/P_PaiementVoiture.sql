CREATE PROCEDURE AjouterPaiementVoiture
 @idPaiement int OUTPUT,
 @nomPaiement varchar(30)
AS
 INSERT INTO PaiementVoiture(nomPaiement)
  VALUES(@nomPaiement)
 SET @idPaiement=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierPaiementVoiture
 @idPaiement int,
 @nomPaiement varchar(30)
AS
 IF(@idPaiement IS NULL OR @idPaiement=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE PaiementVoiture
        SET nomPaiement=@nomPaiement
        WHERE idPaiement=@idPaiement
RETURN
GO
CREATE PROCEDURE SelectionnerPaiementVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomPaiement') SELECT * FROM PaiementVoiture ORDER BY nomPaiement
 ELSE SELECT * FROM PaiementVoiture ORDER BY idPaiement
RETURN
GO
CREATE PROCEDURE SelectionnerPaiementVoiture_ID
 @idPaiement int
AS
 IF(@idPaiement IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idPaiement,nomPaiement
  FROM PaiementVoiture
  WHERE @idPaiement=idPaiement
RETURN
GO
CREATE PROCEDURE SupprimerPaiementVoiture
 @idPaiement int
AS
 IF(@idPaiement IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM PaiementVoiture WHERE @idPaiement=idPaiement
RETURN
GO
