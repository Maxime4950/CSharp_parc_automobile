CREATE PROCEDURE AjouterModeleVoiture
 @idModele int OUTPUT,
 @nomModele varchar(70)
AS
 INSERT INTO ModeleVoiture(nomModele)
  VALUES(@nomModele)
 SET @idModele=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierModeleVoiture
 @idModele int,
 @nomModele varchar(70)
AS
 IF(@idModele IS NULL OR @idModele=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE ModeleVoiture
        SET nomModele=@nomModele
        WHERE idModele=@idModele
RETURN
GO
CREATE PROCEDURE SelectionnerModeleVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomModele') SELECT * FROM ModeleVoiture ORDER BY nomModele
 ELSE SELECT * FROM ModeleVoiture ORDER BY idModele
RETURN
GO
CREATE PROCEDURE SelectionnerModeleVoiture_ID
 @idModele int
AS
 IF(@idModele IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idModele,nomModele
  FROM ModeleVoiture
  WHERE @idModele=idModele
RETURN
GO
CREATE PROCEDURE SupprimerModeleVoiture
 @idModele int
AS
 IF(@idModele IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM ModeleVoiture WHERE @idModele=idModele
RETURN
GO
