CREATE PROCEDURE AjouterDesiterataVoiture
 @idDesiterata int OUTPUT,
 @idClient int,
 @idMarque int,
 @idModele int,
 @idCat int,
 @kilometrageMax int,
 @idCouleur int,
 @idCarburant int,
 @anneeMin int
AS
 INSERT INTO DesiterataVoiture(idClient,idMarque,idModele,idCat,kilometrageMax,idCouleur,idCarburant,anneeMin)
  VALUES(@idClient,@idMarque,@idModele,@idCat,@kilometrageMax,@idCouleur,@idCarburant,@anneeMin)
 SET @idDesiterata=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierDesiterataVoiture
 @idDesiterata int,
 @idClient int,
 @idMarque int,
 @idModele int,
 @idCat int,
 @kilometrageMax int,
 @idCouleur int,
 @idCarburant int,
 @anneeMin int
AS
 IF(@idDesiterata IS NULL OR @idDesiterata=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE DesiterataVoiture
        SET idClient=@idClient,idMarque=@idMarque,idModele=@idModele,idCat=@idCat,kilometrageMax=@kilometrageMax,idCouleur=@idCouleur,idCarburant=@idCarburant,anneeMin=@anneeMin
        WHERE idDesiterata=@idDesiterata
RETURN
GO
CREATE PROCEDURE SelectionnerDesiterataVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='idClient') SELECT * FROM DesiterataVoiture ORDER BY idClient
 ELSE IF(@Index='idMarque') SELECT * FROM DesiterataVoiture ORDER BY idMarque
 ELSE IF(@Index='idModele') SELECT * FROM DesiterataVoiture ORDER BY idModele
 ELSE IF(@Index='idCat') SELECT * FROM DesiterataVoiture ORDER BY idCat
 ELSE IF(@Index='kilometrageMax') SELECT * FROM DesiterataVoiture ORDER BY kilometrageMax
 ELSE IF(@Index='idCouleur') SELECT * FROM DesiterataVoiture ORDER BY idCouleur
 ELSE IF(@Index='idCarburant') SELECT * FROM DesiterataVoiture ORDER BY idCarburant
 ELSE IF(@Index='anneeMin') SELECT * FROM DesiterataVoiture ORDER BY anneeMin
 ELSE SELECT * FROM DesiterataVoiture ORDER BY idDesiterata
RETURN
GO
CREATE PROCEDURE SelectionnerDesiterataVoiture_ID
 @idDesiterata int
AS
 IF(@idDesiterata IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idDesiterata,idClient,idMarque,idModele,idCat,kilometrageMax,idCouleur,idCarburant,anneeMin
  FROM DesiterataVoiture
  WHERE @idDesiterata=idDesiterata
RETURN
GO
CREATE PROCEDURE SupprimerDesiterataVoiture
 @idDesiterata int
AS
 IF(@idDesiterata IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM DesiterataVoiture WHERE @idDesiterata=idDesiterata
RETURN
GO
