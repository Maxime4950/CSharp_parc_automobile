CREATE PROCEDURE AjouterCouleurVoiture
 @idCouleur int OUTPUT,
 @nomCouleur varchar(30)
AS
 INSERT INTO CouleurVoiture(nomCouleur)
  VALUES(@nomCouleur)
 SET @idCouleur=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierCouleurVoiture
 @idCouleur int,
 @nomCouleur varchar(30)
AS
 IF(@idCouleur IS NULL OR @idCouleur=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE CouleurVoiture
        SET nomCouleur=@nomCouleur
        WHERE idCouleur=@idCouleur
RETURN
GO
CREATE PROCEDURE SelectionnerCouleurVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomCouleur') SELECT * FROM CouleurVoiture ORDER BY nomCouleur
 ELSE SELECT * FROM CouleurVoiture ORDER BY idCouleur
RETURN
GO
CREATE PROCEDURE SelectionnerCouleurVoiture_ID
 @idCouleur int
AS
 IF(@idCouleur IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idCouleur,nomCouleur
  FROM CouleurVoiture
  WHERE @idCouleur=idCouleur
RETURN
GO
CREATE PROCEDURE SupprimerCouleurVoiture
 @idCouleur int
AS
 IF(@idCouleur IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM CouleurVoiture WHERE @idCouleur=idCouleur
RETURN
GO
