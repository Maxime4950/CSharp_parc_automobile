CREATE PROCEDURE AjouterCarburantVoiture
 @idCarburant int OUTPUT,
 @nomCarburant varchar(50)
AS
 INSERT INTO CarburantVoiture(nomCarburant)
  VALUES(@nomCarburant)
 SET @idCarburant=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierCarburantVoiture
 @idCarburant int,
 @nomCarburant varchar(50)
AS
 IF(@idCarburant IS NULL OR @idCarburant=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE CarburantVoiture
        SET nomCarburant=@nomCarburant
        WHERE idCarburant=@idCarburant
RETURN
GO
CREATE PROCEDURE SelectionnerCarburantVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomCarburant') SELECT * FROM CarburantVoiture ORDER BY nomCarburant
 ELSE SELECT * FROM CarburantVoiture ORDER BY idCarburant
RETURN
GO
CREATE PROCEDURE SelectionnerCarburantVoiture_ID
 @idCarburant int
AS
 IF(@idCarburant IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idCarburant,nomCarburant
  FROM CarburantVoiture
  WHERE @idCarburant=idCarburant
RETURN
GO
CREATE PROCEDURE SupprimerCarburantVoiture
 @idCarburant int
AS
 IF(@idCarburant IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM CarburantVoiture WHERE @idCarburant=idCarburant
RETURN
GO
