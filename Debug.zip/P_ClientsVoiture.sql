CREATE PROCEDURE AjouterClientsVoiture
 @idClient int OUTPUT,
 @nomClient varchar(50),
 @prenomClient varchar(50),
 @rueClient varchar(100),
 @numeroClient int,
 @boiteClient int,
 @codePoClient int,
 @localiteClient varchar(50)
AS
 INSERT INTO ClientsVoiture(nomClient,prenomClient,rueClient,numeroClient,boiteClient,codePoClient,localiteClient)
  VALUES(@nomClient,@prenomClient,@rueClient,@numeroClient,@boiteClient,@codePoClient,@localiteClient)
 SET @idClient=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierClientsVoiture
 @idClient int,
 @nomClient varchar(50),
 @prenomClient varchar(50),
 @rueClient varchar(100),
 @numeroClient int,
 @boiteClient int,
 @codePoClient int,
 @localiteClient varchar(50)
AS
 IF(@idClient IS NULL OR @idClient=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE ClientsVoiture
        SET nomClient=@nomClient,prenomClient=@prenomClient,rueClient=@rueClient,numeroClient=@numeroClient,boiteClient=@boiteClient,codePoClient=@codePoClient,localiteClient=@localiteClient
        WHERE idClient=@idClient
RETURN
GO
CREATE PROCEDURE SelectionnerClientsVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomClient') SELECT * FROM ClientsVoiture ORDER BY nomClient
 ELSE IF(@Index='prenomClient') SELECT * FROM ClientsVoiture ORDER BY prenomClient
 ELSE IF(@Index='rueClient') SELECT * FROM ClientsVoiture ORDER BY rueClient
 ELSE IF(@Index='numeroClient') SELECT * FROM ClientsVoiture ORDER BY numeroClient
 ELSE IF(@Index='boiteClient') SELECT * FROM ClientsVoiture ORDER BY boiteClient
 ELSE IF(@Index='codePoClient') SELECT * FROM ClientsVoiture ORDER BY codePoClient
 ELSE IF(@Index='localiteClient') SELECT * FROM ClientsVoiture ORDER BY localiteClient
 ELSE SELECT * FROM ClientsVoiture ORDER BY idClient
RETURN
GO
CREATE PROCEDURE SelectionnerClientsVoiture_ID
 @idClient int
AS
 IF(@idClient IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idClient,nomClient,prenomClient,rueClient,numeroClient,boiteClient,codePoClient,localiteClient
  FROM ClientsVoiture
  WHERE @idClient=idClient
RETURN
GO
CREATE PROCEDURE SupprimerClientsVoiture
 @idClient int
AS
 IF(@idClient IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM ClientsVoiture WHERE @idClient=idClient
RETURN
GO
