CREATE PROCEDURE AjouterMarqueVoiture
 @idMarque int OUTPUT,
 @nomMarque varchar(50),
 @paysMarque varchar(50)
AS
 INSERT INTO MarqueVoiture(nomMarque,paysMarque)
  VALUES(@nomMarque,@paysMarque)
 SET @idMarque=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierMarqueVoiture
 @idMarque int,
 @nomMarque varchar(50),
 @paysMarque varchar(50)
AS
 IF(@idMarque IS NULL OR @idMarque=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE MarqueVoiture
        SET nomMarque=@nomMarque,paysMarque=@paysMarque
        WHERE idMarque=@idMarque
RETURN
GO
CREATE PROCEDURE SelectionnerMarqueVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomMarque') SELECT * FROM MarqueVoiture ORDER BY nomMarque
 ELSE IF(@Index='paysMarque') SELECT * FROM MarqueVoiture ORDER BY paysMarque
 ELSE SELECT * FROM MarqueVoiture ORDER BY idMarque
RETURN
GO
CREATE PROCEDURE SelectionnerMarqueVoiture_ID
 @idMarque int
AS
 IF(@idMarque IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idMarque,nomMarque,paysMarque
  FROM MarqueVoiture
  WHERE @idMarque=idMarque
RETURN
GO
CREATE PROCEDURE SupprimerMarqueVoiture
 @idMarque int
AS
 IF(@idMarque IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM MarqueVoiture WHERE @idMarque=idMarque
RETURN
GO
