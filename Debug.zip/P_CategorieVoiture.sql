CREATE PROCEDURE AjouterCategorieVoiture
 @idCat int OUTPUT,
 @nomCat varchar(50)
AS
 INSERT INTO CategorieVoiture(nomCat)
  VALUES(@nomCat)
 SET @idCat=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierCategorieVoiture
 @idCat int,
 @nomCat varchar(50)
AS
 IF(@idCat IS NULL OR @idCat=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE CategorieVoiture
        SET nomCat=@nomCat
        WHERE idCat=@idCat
RETURN
GO
CREATE PROCEDURE SelectionnerCategorieVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='nomCat') SELECT * FROM CategorieVoiture ORDER BY nomCat
 ELSE SELECT * FROM CategorieVoiture ORDER BY idCat
RETURN
GO
CREATE PROCEDURE SelectionnerCategorieVoiture_ID
 @idCat int
AS
 IF(@idCat IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idCat,nomCat
  FROM CategorieVoiture
  WHERE @idCat=idCat
RETURN
GO
CREATE PROCEDURE SupprimerCategorieVoiture
 @idCat int
AS
 IF(@idCat IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM CategorieVoiture WHERE @idCat=idCat
RETURN
GO
