CREATE PROCEDURE AjouterAchatVenteVoiture
 @idOperation int OUTPUT,
 @idVoiture int,
 @idClient int,
 @prixOperation int,
 @dateOperation datetime,
 @idPaiement int
AS
 INSERT INTO AchatVenteVoiture(idVoiture,idClient,prixOperation,dateOperation,idPaiement)
  VALUES(@idVoiture,@idClient,@prixOperation,@dateOperation,@idPaiement)
 SET @idOperation=@@IDENTITY
RETURN
GO
CREATE PROCEDURE ModifierAchatVenteVoiture
 @idOperation int,
 @idVoiture int,
 @idClient int,
 @prixOperation int,
 @dateOperation datetime,
 @idPaiement int
AS
 IF(@idOperation IS NULL OR @idOperation=0)
  RAISERROR('Identifiant requis !',16,1)
 ELSE  UPDATE AchatVenteVoiture
        SET idVoiture=@idVoiture,idClient=@idClient,prixOperation=@prixOperation,dateOperation=@dateOperation,idPaiement=@idPaiement
        WHERE idOperation=@idOperation
RETURN
GO
CREATE PROCEDURE SelectionnerAchatVenteVoiture
 @Index VARCHAR(10)
AS
 IF(@Index='idVoiture') SELECT * FROM AchatVenteVoiture ORDER BY idVoiture
 ELSE IF(@Index='idClient') SELECT * FROM AchatVenteVoiture ORDER BY idClient
 ELSE IF(@Index='prixOperation') SELECT * FROM AchatVenteVoiture ORDER BY prixOperation
 ELSE IF(@Index='dateOperation') SELECT * FROM AchatVenteVoiture ORDER BY dateOperation
 ELSE IF(@Index='idPaiement') SELECT * FROM AchatVenteVoiture ORDER BY idPaiement
 ELSE SELECT * FROM AchatVenteVoiture ORDER BY idOperation
RETURN
GO
CREATE PROCEDURE SelectionnerAchatVenteVoiture_ID
 @idOperation int
AS
 IF(@idOperation IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  SELECT idOperation,idVoiture,idClient,prixOperation,dateOperation,idPaiement
  FROM AchatVenteVoiture
  WHERE @idOperation=idOperation
RETURN
GO
CREATE PROCEDURE SupprimerAchatVenteVoiture
 @idOperation int
AS
 IF(@idOperation IS NULL)
  RAISERROR('Identifiant requis !',16,1)
 ELSE
  DELETE FROM AchatVenteVoiture WHERE @idOperation=idOperation
RETURN
GO
